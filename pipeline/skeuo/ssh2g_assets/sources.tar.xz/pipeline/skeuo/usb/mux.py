"""
Talks usbmux to iOS running in the emulator, like usbmuxd does for a real
device, and opens TCP connections to services on the device.

The device (AppleUSBDeviceMux in iOS 2) speaks mux protocol version 1: every
USB transfer carries one packet with an 8-byte big endian header (protocol,
total length). Protocol 0 is the version handshake, protocol 6 carries a TCP
header followed by data. Windows are exchanged shifted right by 8 bits;
unacknowledged output is retried when the receive window stops advancing.
"""
import plistlib
import struct
import sys
import threading
import time

from .link import USBError

MUX_INTERFACE_CLASS = (0xFF, 0xFE, 0x02)
MUX_HEADER = struct.Struct(">II")
MUX_VERSION = 0
MUX_TCP = 6
VERSION_PAYLOAD = struct.Struct(">III")

TCP_HEADER = struct.Struct(">HHIIBBHHH")
TH_FIN = 0x01
TH_SYN = 0x02
TH_RST = 0x04
TH_ACK = 0x10

RX_WINDOW = 0x20000
MAX_SEGMENT = 0x4000 - MUX_HEADER.size - TCP_HEADER.size
LOCKDOWN_PORT = 62078


class MuxError(Exception):
    pass


class MuxConnection:
    def __init__(self, mux, sport, dport):
        self.mux = mux
        self.sport = sport
        self.dport = dport
        self.tx_seq = 0
        self.tx_ack = 0
        self.tx_acked = 0
        self.tx_win = 0
        self._unacked = bytearray()
        self.state = "connecting"
        self._rx = bytearray()
        self._cond = threading.Condition()
        # Serializes packets so their sequence numbers go out in order,
        # without holding _cond during a USB transfer.
        self._tx_lock = threading.Lock()

    def _send_tcp(self, flags, data=b"", seq=None):
        with self._tx_lock:
            with self._cond:
                header = TCP_HEADER.pack(self.sport, self.dport, self.tx_seq if seq is None else seq, self.tx_ack,
                                         (TCP_HEADER.size // 4) << 4, flags, RX_WINDOW >> 8, 0, 0)
                if seq is None:
                    self.tx_seq += len(data)
                    self._unacked.extend(data)
            self.mux._send(MUX_TCP, header + data)

    def _input(self, flags, seq, ack, win, data):
        send_ack = False
        with self._cond:
            if flags & TH_RST:
                self.state = "refused" if self.state == "connecting" else "closed"
            elif self.state == "connecting" and flags & TH_SYN and flags & TH_ACK:
                self.tx_seq += 1
                self.tx_ack += 1
                self.tx_acked = ack
                self.tx_win = win << 8
                self.state = "connected"
                send_ack = True
            elif self.state == "connected":
                self.tx_win = win << 8
                # usbmuxd acknowledges every device packet, including a pure
                # window update. Match that behavior for the older device stack.
                send_ack = True
                if flags & TH_ACK:
                    advanced = (ack - self.tx_acked) & 0xFFFFFFFF
                    if advanced <= len(self._unacked):
                        del self._unacked[:advanced]
                        self.tx_acked = ack
                if data:
                    self.tx_ack += len(data)
                    self._rx += data
                    send_ack = True
                if flags & TH_FIN:
                    self.state = "closed"
            self._cond.notify_all()
        if send_ack:
            self._send_tcp(TH_ACK)

    def _wait_state(self, timeout):
        with self._cond:
            if not self._cond.wait_for(lambda: self.state != "connecting", timeout):
                raise MuxError("connection to port %d timed out" % self.dport)
            if self.state != "connected":
                raise MuxError("connection to port %d refused" % self.dport)

    def _in_flight(self):
        return (self.tx_seq - self.tx_acked) & 0xFFFFFFFF

    def send(self, data, timeout=60):
        """Sends data, waiting while the device's receive window is full."""
        offset = 0
        deadline = time.monotonic() + timeout
        while offset < len(data):
            with self._cond:
                ready = self._cond.wait_for(lambda: self.state != "connected"
                                           or self._in_flight() < self.tx_win,
                                           min(0.5, max(0, deadline - time.monotonic())))
                if self.state != "connected":
                    raise MuxError("connection closed")
                if not ready:
                    if time.monotonic() >= deadline:
                        raise MuxError("timed out waiting for port %d's receive window" % self.dport)
                    retry = bytes(self._unacked[:MAX_SEGMENT])
                    seq = self.tx_acked
                else:
                    retry = None
                    # 1.x can advertise less than MAX_SEGMENT. Waiting for a full
                    # segment leaves both peers waiting with usable space.
                    size = min(MAX_SEGMENT, self.tx_win - self._in_flight(), len(data) - offset)
                    segment = data[offset:offset + size]
            if retry is not None:
                if retry:
                    self._send_tcp(TH_ACK, retry, seq=seq)
                continue
            self._send_tcp(TH_ACK, segment)
            offset += size
            deadline = time.monotonic() + timeout

    def recv(self, bufsize, timeout=None):
        """Returns up to bufsize bytes as soon as some are available, or b""
        once the connection is closed."""
        with self._cond:
            if not self._cond.wait_for(lambda: self._rx or self.state != "connected", timeout):
                raise MuxError("timed out waiting for data")
            data = bytes(self._rx[:bufsize])
            del self._rx[:bufsize]
            return data

    def recv_exact(self, length, timeout=10):
        with self._cond:
            if not self._cond.wait_for(lambda: len(self._rx) >= length or self.state != "connected", timeout):
                raise MuxError("timed out waiting for %d bytes" % length)
            if len(self._rx) < length:
                raise MuxError("connection closed")
            data = bytes(self._rx[:length])
            del self._rx[:length]
            return data

    def close(self):
        with self._cond:
            connected = self.state == "connected"
            self.state = "closed"
            self._cond.notify_all()
        if connected:
            try:
                self._send_tcp(TH_RST)
            except (USBError, ConnectionError, OSError):
                pass
        self.mux._forget(self)


class MuxDevice:
    """Selects the configuration with the usbmux interface and runs the mux
    protocol on its bulk endpoints."""

    def __init__(self, link):
        self.link = link
        desc = link.wait_for_device()
        link.ctrl_transfer(0x00, 0x05, 1, 0)  # SET_ADDRESS, before configuration
        self.vid, self.pid = struct.unpack_from("<HH", desc, 8)
        self.serial = link.get_string(desc[16]) if desc[16] else ""
        self._find_interface(link.get_configurations(desc[17]))
        link.ctrl_transfer(0x00, 0x09, self.config, 0)  # SET_CONFIGURATION

        self._send_lock = threading.Lock()
        self._conns = {}
        self._conns_lock = threading.Lock()
        self._next_port = 1
        self._version = None
        self._version_event = threading.Event()
        self._closing = False
        self.closed = threading.Event()
        self._reader = threading.Thread(target=self._read_loop, daemon=True)
        self._reader.start()

    def _find_interface(self, configs):
        for config in configs:
            for intf in config["interfaces"]:
                if (intf["class"], intf["subclass"], intf["protocol"]) != MUX_INTERFACE_CLASS:
                    continue
                eps = {ep["address"] & 0x80: ep for ep in intf["endpoints"] if ep["type"] == 2}
                if 0x00 in eps and 0x80 in eps:
                    self.config = config["value"]
                    self.out_ep = eps[0x00]["address"]
                    self.out_mps = eps[0x00]["max_packet"]
                    self.in_ep = eps[0x80]["address"] & 0x7F
                    return
        raise MuxError("device has no usbmux interface")

    def _send(self, protocol, payload):
        packet = MUX_HEADER.pack(protocol, MUX_HEADER.size + len(payload)) + payload
        with self._send_lock:
            self.link.bulk_write(self.out_ep, packet, timeout=30)
            # The device needs the transfer to end to see the packet.
            if len(packet) % self.out_mps == 0:
                self.link.bulk_write(self.out_ep, b"", timeout=30)

    def _read_loop(self):
        buf = bytearray()
        try:
            while True:
                buf += self.link.bulk_read(self.in_ep, 0x10000)
                while len(buf) >= MUX_HEADER.size:
                    protocol, length = MUX_HEADER.unpack_from(buf)
                    if length < MUX_HEADER.size or len(buf) < length:
                        break
                    self._dispatch(protocol, bytes(buf[MUX_HEADER.size:length]))
                    del buf[:length]
        except (USBError, ConnectionError, OSError) as e:
            if not self._closing:
                print("usbmux: reader stopped: %s" % e, file=sys.stderr)
            with self._conns_lock:
                conns = list(self._conns.values())
            for conn in conns:
                conn._input(TH_RST, 0, 0, 0, b"")
        finally:
            self.closed.set()

    def _dispatch(self, protocol, payload):
        if protocol == MUX_VERSION:
            self._version = VERSION_PAYLOAD.unpack_from(payload)[:2]
            self._version_event.set()
        elif protocol == MUX_TCP and len(payload) >= TCP_HEADER.size:
            sport, dport, seq, ack, offset, flags, win, _, _ = TCP_HEADER.unpack_from(payload)
            with self._conns_lock:
                conn = self._conns.get(dport)
            if conn:
                conn._input(flags, seq, ack, win, payload[(offset >> 4) * 4:])
        else:
            print("usbmux: dropping packet with protocol %d" % protocol, file=sys.stderr)

    def handshake(self, timeout=5):
        """Returns the (major, minor) mux version of the device."""
        self._send(MUX_VERSION, VERSION_PAYLOAD.pack(1, 0, 0))
        if not self._version_event.wait(timeout):
            raise MuxError("no version reply")
        return self._version

    def connect(self, port, timeout=10):
        with self._conns_lock:
            sport = self._next_port
            self._next_port = self._next_port % 0xFFFF + 1
            conn = MuxConnection(self, sport, port)
            self._conns[sport] = conn
        conn._send_tcp(TH_SYN)
        try:
            conn._wait_state(timeout)
        except MuxError:
            self._forget(conn)
            raise
        return conn

    def close(self):
        self._closing = True
        self.link.close()
        self._reader.join(timeout=1)

    def _forget(self, conn):
        with self._conns_lock:
            self._conns.pop(conn.sport, None)


def lockdown_request(conn, request):
    body = plistlib.dumps(request)
    conn.send(struct.pack(">I", len(body)) + body)
    length = struct.unpack(">I", conn.recv_exact(4))[0]
    return plistlib.loads(conn.recv_exact(length))

